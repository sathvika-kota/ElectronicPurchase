package com.cg.es.exceptions;

public class BasketNotFoundException extends Exception {

	public BasketNotFoundException(String message) {
		super(message);
	}

}

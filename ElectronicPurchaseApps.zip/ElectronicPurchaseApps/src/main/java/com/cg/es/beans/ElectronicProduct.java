package com.cg.es.beans;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Electronic_Product")
public class ElectronicProduct {

	@Id
	@Column(name = "code")
	private String code;
	@Column(name = "product_name")
	private String name;
	@Column(name = "price")
	private double price;
	@Column(name = "image")
	private String image;
	@Column(name = "create_date")
	private LocalDate createDate;
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "prd_type_id", nullable = false)
	private ProductType productType;

	public ElectronicProduct(String code, String name, double price, String image, LocalDate createDate,
			ProductType productType) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.image = image;
		this.createDate = createDate;
		this.productType = productType;
	}

	public ElectronicProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public LocalDate getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}

	public ProductType getProductType() {
		return productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "ElectronicProduct [code=" + code + ", name=" + name + ", price=" + price + ", image=" + image
				+ ", productType=" + productType + "]";
	}

}

package com.cg.es.services;

import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.beans.Basket;
import com.cg.es.beans.ElectronicProduct;
import com.cg.es.exceptions.BasketNotFoundException;
import com.cg.es.repository.BasketRepository;

@Service
@Transactional
public class BasketServiceImpl implements BasketService {
	@Autowired
	private BasketRepository basketRepository;

	@Override
	public Basket addBasket(Basket basket) {
		return basketRepository.save(basket);
	}

	@Override
	public void removeBasket(int basketId) throws BasketNotFoundException {
		basketRepository.deleteById(basketId);
	}

	@Override
	public Basket addProduct(Basket basket, ElectronicProduct pr, int quantity) {
		return basketRepository.save(basket);
	}

	public Basket updateQuantityInBasket(Basket basket, ElectronicProduct pr, int quantity) {
		return basketRepository.save(basket);
	}

	@Override
	public double totalCost(int basketId) {
		Basket basket = basketRepository.findById(basketId).get();
		Map<Integer, ElectronicProduct> productsMap = basket.getProductList();
		Set<Integer> prodIds = productsMap.keySet();
		double totCost = 0;
		for (int prodId : prodIds) {
			totCost = totCost + ((ElectronicProduct) productsMap.get(prodId)).getPrice();
		}
		return totCost;
	}

	@Override
	public Basket getBasket(int basketId) {
		Basket basket = basketRepository.findById(basketId).get();
		return basket;
	}
}

package com.cg.es.services;

import com.cg.es.beans.Basket;
import com.cg.es.beans.ElectronicProduct;
import com.cg.es.exceptions.BasketNotFoundException;

public interface BasketService {

	public Basket addBasket(Basket basket);

	public void removeBasket(int basketId) throws BasketNotFoundException;

	public Basket addProduct(Basket basket, ElectronicProduct pr, int quantity);

	public Basket updateQuantityInBasket(Basket basket, ElectronicProduct pr, int quantity);

	public double totalCost(int basketId);

	public Basket getBasket(int basketId);

}

package com.cg.es.beans;

import java.util.Map;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.type.TrueFalseType;

@Entity
@Table(name = "cart")
public class Basket {

	@Id
	@Column(name = "basket_id")
	private Integer basketId;

	@Column(name = "total_cost")
	private double totalCost;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	@OneToMany( fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Map<Integer, ElectronicProduct> productList;

	public Basket() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Basket(Integer basketId, Customer customer, double totalCost, Map<Integer, ElectronicProduct> productList) {
		super();
		this.basketId = basketId;
		this.customer = customer;
		this.totalCost = totalCost;
		this.productList = productList;
	}

	public Integer getBasketId() {
		return basketId;
	}

	public void setBasketId(Integer basketId) {
		this.basketId = basketId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public Map<Integer, ElectronicProduct> getProductList() {
		return productList;
	}

	public void setProductList(Map<Integer, ElectronicProduct> productList) {
		this.productList = productList;
	}

	@Override
	public String toString() {
		return "Basket [basketId=" + basketId + ", totalCost=" + totalCost + "]";
	}

}

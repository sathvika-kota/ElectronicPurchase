package com.cg.es.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.es.beans.Basket;
import com.cg.es.beans.ElectronicProduct;

public interface BasketRepository extends JpaRepository<Basket, Integer> {

	
}

package com.cg.es.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_type")
public class ProductType {
	@Id
	@Column(name = "prd_type_id")
	private Integer prdTypeId;
	@Column(name = "prd_name")
	private String name;

	public ProductType(Integer prdTypeId, String name) {
		super();
		this.prdTypeId = prdTypeId;
		this.name = name;
	}

	public ProductType() {
		super();
	}

	public Integer getPrdTypeId() {
		return prdTypeId;
	}

	public void setPrdTypeId(Integer prdTypeId) {
		this.prdTypeId = prdTypeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ProductType [prdTypeId=" + prdTypeId + ", name=" + name + "]";
	}
}

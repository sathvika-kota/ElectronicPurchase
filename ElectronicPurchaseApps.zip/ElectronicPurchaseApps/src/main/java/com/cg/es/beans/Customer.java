package com.cg.es.beans;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {

	@Id
	@Column(name = "customer_id")
	private String customerId;
	@Column(name = "customer_name")
	private String customerName;
	@Column(name = "customer_email")
	private String customerEmail;
	@Column(name = "customer_phone")
	private String customerPhone;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	private Address customerAddress;
	@OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL,mappedBy = "customer")
	private Set<ElectronicProductOrder> electronicProductOrderSet;
	@OneToMany( fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	private List<ElectronicProduct> productList;
	
	public Customer(String customerId, String customerName, String customerEmail, String customerPhone,
			Address customerAddress, Set<ElectronicProductOrder> electronicProductOrderSet,
			List<ElectronicProduct> productListt) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPhone = customerPhone;
		this.customerAddress = customerAddress;
		this.electronicProductOrderSet = electronicProductOrderSet;
		this.productList = productList;
		//this.basket = basket;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public Address getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(Address customerAddress) {
		this.customerAddress = customerAddress;
	}

	public Set<ElectronicProductOrder> getElectronicProductOrderSet() {
		return electronicProductOrderSet;
	}

	public void setElectronicProductOrderSet(Set<ElectronicProductOrder> electronicProductOrderSet) {
		this.electronicProductOrderSet = electronicProductOrderSet;
	}

	public List<ElectronicProduct> getProductList() {
		return productList;
	}

	public void setProductList(List<ElectronicProduct> productList) {
		this.productList = productList;
	}

//	public Basket getBasket() {
//		return basket;
//	}
//
//	public void setBasket(Basket basket) {
//		this.basket = basket;
//	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerPhone=" + customerPhone + ", customerAddress=" + customerAddress
				+ "]";
	}

}

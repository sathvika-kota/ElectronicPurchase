package com.cg.es.controller;

import org.hibernate.sql.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.es.beans.Basket;
import com.cg.es.beans.ElectronicProduct;
import com.cg.es.exceptions.BasketNotFoundException;
import com.cg.es.services.BasketService;

@RestController
@RequestMapping("/basket")
public class BasketController {

	@Autowired
	private BasketService basketService;

	@PostMapping("/addbasket")
	public Basket addbasket(@RequestBody Basket basket) {
		return basketService.addBasket(basket);
	}

	@DeleteMapping("/deletebasket/{basketId}")
	public void removebasket(@PathVariable int basketId) throws BasketNotFoundException {
		basketService.removeBasket(basketId);

	}

	@PostMapping("/basketProduct")
	public Basket addProduct(@RequestBody Basket basket, ElectronicProduct pr, int quantity) {
		return basketService.addProduct(basket, pr, quantity);
	}

	@PutMapping("/updatebasket")
	public ResponseEntity<Basket> updateBasket(@RequestBody Basket basket, ElectronicProduct pr, int quantity) {
		return new ResponseEntity<Basket>(basketService.updateQuantityInBasket(basket, pr, quantity), HttpStatus.OK);
	}
	@GetMapping("/selectbasket/{basketId}")
	public Basket getBasket(@PathVariable Integer basketId) {
		return basketService.getBasket(basketId);
	}
}
